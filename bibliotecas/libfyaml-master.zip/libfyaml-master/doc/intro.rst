Introduction
============

This is the documentation for libfyaml, a fancy 1.2 YAML and JSON parser/writer.
