#ifndef HIG_FLOW_VOF_9_CELLS
#define HIG_FLOW_VOF_9_CELLS

void higflow_compute_normal_multiphase_2D_shirani_9_cells(higflow_solver *ns, sim_domain *sdp, int clid, Point center, Point p, Point delta);

#endif
